# whatsapp_hack
Whatsapp web'i klonlanmış bir web sitesiyle hackleyin

## gereksinimler
 - Python> = 3.6.3
 - Şişesi == 1.0.2
 - Selenyum == 3.7.0
 - [Gecko Sürücüsü] (https://github.com/mozilla/geckodriver/releases)


## feragatname

BU SADECE NEDENLİ AMAÇLAR İÇİNDİR.

HERHANGİ BİR NEDEN İÇİN GERÇEK VICTIMLER KULLANMAYIN. CEZA HUKUKU BAŞVURACAKTIR.
 
## kullanım
repo klonu:
        
    git klonu https://github.com/raptored01/whatsapp_hack.git

gereksinimleri yükle

    cd yolu / to / the / repo
    pip kurulum -r needs.txt
    
ilk önce 

    python3 Instagram Hesabındaki Resim ve Videoları grabber.py
    
sonra sunucuyu çalıştır

    python3 server.py
    
    
Sahte web sitesinde, tarayıcıda whatsapp web  tarafından kurbanın numarasına bağlanacak.

## Kullanmadan önce:
 - server.py betiğinin son satırını gereksinimlerinize uyacak şekilde değiştirin
 (80 numaralı bağlantı noktasında çalıştırıyorsanız, süper kullanıcı olarak çalıştırmanız gerekebilir)
 - yönlendirici yapılandırması gerekli olabilir (port eşleştirme)